<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class KTP_Model extends CI_Model {

    // get
    public function get($param = null)
    {
        
        $this->db->select('id, nik, nama, tempat_lahir, tgl_lahir, alamat, rt, rw, kelurahan, kecamatan, kabupaten, provinsi, kodepos, jenis_kelamin, golongan_darah, status_perkawinan, agama, pekerjaan, kewarganegaraan');
        $this->db->where('deleted_at', null);
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_master_ktp');
    }

    // num row
    public function count($param = null)
    {
        
        $this->db->where('deleted_at', null);
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_master_ktp')->num_rows();
    }

    // last update
    public function last_update()
    {
        $this->db->select_max('created_at');
        $this->db->where('deleted_at', null);

        return $this->db->get('tbl_master_ktp');
    }

}

/* End of file KTP_Model.php */
