<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_Model extends CI_Model {

    // data tagihan
    public function get_tagihan($param = null)
    {
        $this->db->where('tanggal_lunas', '1980/01/01');
        $this->db->order_by('tanggal_ar', 'asc');
        
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_accardat');
    }

    // count tagihan
    public function count_tagihan($param = null)
    {
        $this->db->where('tanggal_lunas', '1980/01/01');
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_accardat')->num_rows();
    }

    // total tagihan
    public function total_tagihan($param = null)
    {
        $this->db->where('tanggal_lunas', '1980/01/01');
        $this->db->select_sum('sisa_ar');
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_accardat');
    }

    // best buyer
    public function best_buyer($year, $month, $limit)
    {
        if ($year != null && $month != null) {
            $date = $year.'-'.$month;
            $this->db->where("DATE_FORMAT(tanggal_bon,'%Y-%m')", $date);
        } else if ($year != null && $month == null) {
            $this->db->where("DATE_FORMAT(tanggal_bon,'%Y')", $year);
        } else if ($year == null && $month != null) {
            $this->db->where("DATE_FORMAT(tanggal_bon,'%m')", $month);
        }

        $this->db->select('ta.kode_pelanggan, lgn.nama_toko, COUNT(ta.kode_pelanggan) as total_transaction, SUM(prf_barang) as total_purchase');
        $this->db->join('tbl_accdlgn lgn', 'lgn.kode_pelanggan = ta.kode_pelanggan', 'left');
        $this->db->group_by('ta.kode_pelanggan');
        $this->db->having('SUM(prf_barang) >',  0);
        $this->db->order_by('total_transaction', 'desc');
        if ($limit > 0) {
            $this->db->limit($limit);
        }
        
        return $this->db->get('tbl_accarbon ta');
    }

    // best seller
    public function best_seller($year, $month, $limit)
    {
        if ($year != null && $month != null) {
            $date = $year.'-'.$month;
            $this->db->where("DATE_FORMAT(tanggal_bon,'%Y-%m')", $date);
        } else if ($year != null && $month == null) {
            $this->db->where("DATE_FORMAT(tanggal_bon,'%Y')", $year);
        } else if ($year == null && $month != null) {
            $this->db->where("DATE_FORMAT(tanggal_bon,'%m')", $month);
        }

        $this->db->select('ta.kode_barang, br.nama_barang, COUNT(ta.kode_barang) as quantity, SUM(ta.prf_barang) as total_purchase');
        $this->db->join('tbl_accdbrg br', 'br.kode_barang = ta.kode_barang', 'left');
        
        $this->db->group_by('ta.kode_barang');
        $this->db->having('SUM(ta.prf_barang) >',  0);
        $this->db->order_by('quantity', 'desc');
        if ($limit > 0) {
            $this->db->limit($limit);
        }
        
        return $this->db->get('tbl_accarbon ta');
    }

    // last update tagihan
    public function last_update_tagihan()
    {
        $this->db->select_max('created_at');
        return $this->db->get('tbl_accardat');
    }

    // count KTP
    public function count_ktp($param = null)
    {
        
        $this->db->where('deleted_at', null);
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_master_ktp')->num_rows();
    }

    // last update KTP
    public function last_update_ktp()
    {
        $this->db->select_max('created_at');
        $this->db->where('deleted_at', null);

        return $this->db->get('tbl_master_ktp');
    }

    // count NPWP
    public function count_npwp($param = null)
    {
        
        $this->db->where('deleted_at', null);
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_master_npwp')->num_rows();
    }

    // last update NPWP
    public function last_update_npwp()
    {
        $this->db->select_max('created_at');
        $this->db->where('deleted_at', null);

        return $this->db->get('tbl_master_npwp');
    }

    // count accdbrg
    public function count_accdbrg($param = null)
    {
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_accdbrg')->num_rows();
    }

    // last update accdbrg
    public function last_update_accdbrg()
    {
        $this->db->select_max('created_at');
        return $this->db->get('tbl_accdbrg');
    }
    
    // count accdlgn
    public function count_accdlgn($param = null)
    {
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_accdlgn')->num_rows();
    }

    // last update accdlgn
    public function last_update_accdlgn()
    {
        $this->db->select_max('created_at');
        return $this->db->get('tbl_accdlgn');
    }

    // count accarbon
    public function count_accarbon($param = null)
    {
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_accarbon')->num_rows();
    }

    // last update accarbon
    public function last_update_accarbon()
    {
        $this->db->select_max('created_at');
        return $this->db->get('tbl_accarbon');
    }
    
    // count accardat
    public function count_accardat($param = null)
    {
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_accardat')->num_rows();
    }

    // last update accardat
    public function last_update_accardat()
    {
        $this->db->select_max('created_at');
        return $this->db->get('tbl_accardat');
    }

}

/* End of file Dashboard_Model.php */
