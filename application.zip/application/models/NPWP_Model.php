<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class NPWP_Model extends CI_Model {

    // get
    public function get($param = null)
    {
        
        $this->db->select('id, npwp, nik, nama, alamat, nomor, blok, rt, rw, kelurahan, kecamatan, kabupaten, provinsi, kodepos, nomor_telepon');
        $this->db->where('deleted_at', null);
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_master_npwp');
    }

    // num row
    public function count($param = null)
    {
        
        $this->db->where('deleted_at', null);
        if ($param != null) {
            $this->db->where('id', $param);
        }
        
        return $this->db->get('tbl_master_npwp')->num_rows();
    }

    // last update
    public function last_update()
    {
        $this->db->select_max('created_at');
        $this->db->where('deleted_at', null);

        return $this->db->get('tbl_master_npwp');
    }

}

/* End of file NPWP_Model.php */
