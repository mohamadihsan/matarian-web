<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Login';
$route['404_override'] = 'ErrorPage';
$route['translate_uri_dashes'] = FALSE;


$route['api/web/v1/test']['GET']                 = 'api/web/v1/TestApi/index';

//==================================== WEB ROUTES =====================================

$route['ktp']                   = 'KTP/index';
$route['npwp']                  = 'NPWP/index';
$route['import-document']       = 'Import_Document/index';



//==================================== API ROUTES MOBILE =====================================

// Dashboard
$route['api/mobile/v1/dashboard/tagihan']['GET']               = 'api/mobile/v1/Dashboard_Api/show_all_tagihan';
$route['api/mobile/v1/dashboard/tagihan/count']['GET']         = 'api/mobile/v1/Dashboard_Api/count_tagihan';
$route['api/mobile/v1/dashboard/ktp/count']['GET']             = 'api/mobile/v1/Dashboard_Api/count_ktp';
$route['api/mobile/v1/dashboard/npwp/count']['GET']            = 'api/mobile/v1/Dashboard_Api/count_npwp';
$route['api/mobile/v1/dashboard/accdbrg/count']['GET']         = 'api/mobile/v1/Dashboard_Api/count_accdbrg';
$route['api/mobile/v1/dashboard/accdlgn/count']['GET']         = 'api/mobile/v1/Dashboard_Api/count_accdlgn';
$route['api/mobile/v1/dashboard/accarbon/count']['GET']        = 'api/mobile/v1/Dashboard_Api/count_accarbon';
$route['api/mobile/v1/dashboard/accardat/count']['GET']        = 'api/mobile/v1/Dashboard_Api/count_accardat';
$route['api/mobile/v1/dashboard/best-buyer/year/(:num)/month/(:num)/limit/(:num)']['GET']     = 'api/mobile/v1/Dashboard_Api/best_buyer/$1/$2/$3';
$route['api/mobile/v1/dashboard/best-seller/year/(:num)/month/(:num)/limit/(:num)']['GET']    = 'api/mobile/v1/Dashboard_Api/best_seller/$1/$2/$3';



//==================================== API ROUTES WEB =====================================

// Dashboard 
$route['api/web/v1/dashboard/tagihan']['GET']               = 'api/web/v1/Dashboard_Api/show_all_tagihan';
$route['api/web/v1/dashboard/tagihan/count']['GET']         = 'api/web/v1/Dashboard_Api/count_tagihan';
$route['api/web/v1/dashboard/ktp/count']['GET']             = 'api/web/v1/Dashboard_Api/count_ktp';
$route['api/web/v1/dashboard/npwp/count']['GET']            = 'api/web/v1/Dashboard_Api/count_npwp';
$route['api/web/v1/dashboard/accdbrg/count']['GET']         = 'api/web/v1/Dashboard_Api/count_accdbrg';
$route['api/web/v1/dashboard/accdlgn/count']['GET']         = 'api/web/v1/Dashboard_Api/count_accdlgn';
$route['api/web/v1/dashboard/accarbon/count']['GET']        = 'api/web/v1/Dashboard_Api/count_accarbon';
$route['api/web/v1/dashboard/accardat/count']['GET']        = 'api/web/v1/Dashboard_Api/count_accardat';
$route['api/web/v1/dashboard/best-buyer/year/(:num)/month/(:num)/limit/(:num)']['GET']     = 'api/web/v1/Dashboard_Api/best_buyer/$1/$2/$3';
$route['api/web/v1/dashboard/best-seller/year/(:num)/month/(:num)/limit/(:num)']['GET']    = 'api/web/v1/Dashboard_Api/best_seller/$1/$2/$3';

// Wilayah
$route['api/provinsi']['GET']                   = 'api/Wilayah_Api/provinsi';
$route['api/provinsi']['POST']                  = 'api/Wilayah_Api/provinsi';
$route['api/kabupaten/(:num)']['GET']           = 'api/Wilayah_Api/kabupaten/$1';
$route['api/kabupaten/(:num)/(:any)']['GET']    = 'api/Wilayah_Api/kabupaten/$1/$2';
$route['api/kecamatan/(:num)']['GET']           = 'api/Wilayah_Api/kecamatan/$1';
$route['api/kecamatan/(:num)/(:any)']['GET']    = 'api/Wilayah_Api/kecamatan/$1/$2';
$route['api/kelurahan/(:num)']['GET']           = 'api/Wilayah_Api/kelurahan/$1';
$route['api/kelurahan/(:num)/(:any)']['GET']    = 'api/Wilayah_Api/kelurahan/$1/$2';
$route['api/kode-pos/(:num)']['GET']            = 'api/Wilayah_Api/kode_pos/$1';
$route['api/kode-pos/(:num)/(:any)']['GET']     = 'api/Wilayah_Api/kode_pos/$1/$2';

// KTP
$route['api/web/v1/ktp']['GET']                 = 'api/web/v1/KTP_Api/show_all';
$route['api/web/v1/ktp/count']['GET']           = 'api/web/v1/KTP_Api/count';
$route['api/web/v1/ktp/(:num)']['GET']          = 'api/web/v1/KTP_Api/show_by_id/$1';
$route['api/web/v1/ktp']['POST']                = 'api/web/v1/KTP_Api/create';
$route['api/web/v1/ktp/(:num)']['PUT']          = 'api/web/v1/KTP_Api/update/$1';
$route['api/web/v1/ktp']['DELETE']              = 'api/web/v1/KTP_Api/destroy';
$route['api/web/v1/ktp/(:num)/approve']['GET']  = 'api/web/v1/KTP_Api/approve/$1';
$route['api/web/v1/ktp/(:num)/reject']['GET']   = 'api/web/v1/KTP_Api/reject/$1';

// NPWP
$route['api/web/v1/npwp']['GET']                 = 'api/web/v1/NPWP_Api/show_all';
$route['api/web/v1/npwp/count']['GET']           = 'api/web/v1/NPWP_Api/count';
$route['api/web/v1/npwp/(:num)']['GET']          = 'api/web/v1/NPWP_Api/show_by_id/$1';
$route['api/web/v1/npwp']['POST']                = 'api/web/v1/NPWP_Api/create';
$route['api/web/v1/npwp/(:num)']['PUT']          = 'api/web/v1/NPWP_Api/update/$1';
$route['api/web/v1/npwp']['DELETE']              = 'api/web/v1/NPWP_Api/destroy';
$route['api/web/v1/npwp/(:num)/approve']['GET']  = 'api/web/v1/NPWP_Api/approve/$1';
$route['api/web/v1/npwp/(:num)/reject']['GET']   = 'api/web/v1/NPWP_Api/reject/$1';

// Import Document
$route['api/web/v1/import-document']['POST']    = 'api/web/v1/Import_Document_Api/create';
