<!-- assets -->
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/axios/dist/axios.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/jquery-easy-loading/dist/jquery.loading.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="<?= base_url('assets/'); ?>js/katapanda.min.js"></script>
<script src="<?= base_url('assets/'); ?>js/my.js"></script>
<script src="<?= base_url('assets/'); ?>js/version.min.js"></script>

</body>

</html>