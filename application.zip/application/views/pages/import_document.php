<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.rawgit.com/enyo/dropzone/master/dist/dropzone.css">

<div class="container">
    <div class="d-sm-flex align-items-center justify-content-between mb-4 katapanda-hide-element">
        <div class="d-flex flex-row">
            
            <div class="card h-100">
                <div class="card-body">
                    <a href="#" style="color: #757575; text-decoration: none;">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-uppercase mb-1">Document ACCDBRG</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><span id="sumACCDBRG"></span></div>
                                <div class="mt-2 mb-0 text-muted text-xs">
                                    <span class="text-success mr-2"><i class="far fa-calendar"></i></span>
                                    <span id="lastUpdateACCDBRG"></span><br/>
                                    <span>last update</span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="far fa-file fa-2x text-primary"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="card h-100 ml-2">
                <div class="card-body">
                    <a href="#" style="color: #757575; text-decoration: none;">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-uppercase mb-1">Document ACCDLGN</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><span id="sumACCDLGN"></span></div>
                                <div class="mt-2 mb-0 text-muted text-xs">
                                    <span class="text-success mr-2"><i class="far fa-calendar"></i></span>
                                    <span id="lastUpdateACCDLGN"></span><br/>
                                    <span>last update</span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="far fa-file fa-2x text-warning"></i>
                            </div>
                        </div>
                    </a>    
                </div>
            </div>
            <div class="card h-100 ml-2">
                <div class="card-body">
                    <a href="#" style="color: #757575; text-decoration: none;">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-uppercase mb-1">Document ACCARBON</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><span id="sumACCARBON"></span></div>
                                <div class="mt-2 mb-0 text-muted text-xs">
                                    <span class="text-success mr-2"><i class="far fa-calendar"></i></span>
                                    <span id="lastUpdateACCARBON"></span><br/>
                                    <span>last update</span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="far fa-file fa-2x text-success"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="card h-100 ml-2">
                <div class="card-body">
                    <a href="#" style="color: #757575; text-decoration: none;">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-uppercase mb-1">Document ACCARDAT</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><span id="sumACCARDAT"></span></div>
                                <div class="mt-2 mb-0 text-muted text-xs">
                                    <span class="text-success mr-2"><i class="far fa-calendar"></i></span>
                                    <span id="lastUpdateACCARDAT"></span><br/>
                                    <span>last update</span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="far fa-file fa-2x text-info"></i>
                            </div>
                        </div>
                    </a>    
                </div>
            </div>
        </div>
    </div>

	<div class="row my-4">
		<div class="col">
			<div class="jumbotron" style="padding: 1rem 2rem">
				<h1><?= $title ?></h1>
				<p class="text-muted">Please select type of document before upload!</p>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label class="label-katapanda-sm" for="typeOfDocument">Type of Document <span class="text-danger">*</span></label>
                        <select name="typeOfDocument" id="typeOfDocument" class="selectpicker form-control form-control-md"  data-live-search="true"  title="Choose" style="border-color: #fff;">
                            <option value="ACCDBRG">Document ACCDBRG</option>
                            <option value="ACCDLGN">Document ACCDLGN</option>
                            <option value="ACCARBON">Document ACCARBON</option>
                            <option value="ACCARDAT">Document ACCARDAT</option>
                        </select>
                        <span id="errorTypeOfDocument"></span>
                    </div> 
                    <div class="form-group col-md-4">
                        <span id="templateDocument"></span>
                    </div>
                    <div class="form-group col-md-12">
                        <label class="label-katapanda-sm" for="File">File Document <span class="text-danger">*</span></label>
            
                        <form action="" method="post" class="dropzone dz-clickable" id="" enctype="multipart/form-data">
                            <div class="dz-message d-flex flex-column">
                                <i class="material-icons text-muted">cloud_upload</i>
                                Drag &amp; Drop here or click
                            </div>
                        </form>
                        <button type="button" class="btn bg-custom btn-block" id="btn_upload">UPLOAD</button>
                    </div>
                </div>        
				
			</div>
		</div>
	</div>
</div>

<script src="https://cdn.rawgit.com/enyo/dropzone/master/dist/dropzone.js"></script>

<script>
Dropzone.autoDiscover = false;

var myDropzone = new Dropzone(".dropzone", { 
    url: `<?= site_url() ?>api/web/v1/import-document`,
    headers: {
        Authorization: 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MX0.kIAAEvot-QVTM_uFWtQtISAhZGxs6GUCtjMWIssCprU' 
    },
    paramName: "file",
    autoProcessQueue: false,
    uploadMultiple: false,
    maxFiles: 1,
    maxFilesize: 5,
    addRemoveLinks: true,
    acceptedFiles: ".xlsx, .xls",
    init: function() {
        this.on("maxfilesexceeded", function(file){
            notification('upload', 'error', 'No more files please!');
        });
        this.on('success', function(file, resp){
            // console.log(file);
            // console.log(resp);
        });
    },
    accept: function(file, done) {
        // console.log("upload");
        done();
    },
    maxfilesexceeded: function(file) {
        this.removeFile(file);
        // this.removeAllFiles();
        // this.addFile(file);
    },
    sending: function(file, xhr, data){
        // console.log('sending');
        data.append('type_document', $('#typeOfDocument').val());
        // xhr.addEventListener("load", () => {
        //     console.log(xhr.status);
        //     notification('upload', 'error', 'Server has a problem. Please contact Administartor!');    
            
        // });
    },
    uploadprogress: function(file, progress, bytesSent) {
        // console.log('Loading');
        // start loading
        loadingStart()
    },
    success: function (file, response) {
        // console.log(response);
        let status = 'error';
        if (response.status == true) {
            status = 'success';
        }

        notification('upload', status, response.message);    

    },
    complete: function(file) {
        this.removeFile(file);
        // stop loading
        loadingStop()
    }
});

$('#btn_upload').click(function(){
    if ($('#typeOfDocument').val() == '') {
        $('#errorTypeOfDocument').html('<span class="text-katapanda-sm text-custom">Please enter Type of Document</span>')
    }else{
        myDropzone.processQueue();
    }
    
});

$('#typeOfDocument').change(function() {
    let type = $('#typeOfDocument').val();
    let link = '';

    if (type == 'ACCDBRG') {
        link = '1';
    } else if (type == 'ACCDLGN') {
        link = '2';
    } else if (type == 'ACCARBON') {
        link = '3';
    } else if (type == 'ACCARDAT') {
        link = '4';
    } 
    $('#templateDocument').html(`<label class="label-katapanda-sm" for="downloadTemplate">
                                    Template document
                                </label><br/>
                                <a href="${link}" class="btn btn-sm btn-outline-primary" title="Download template document">
                                    <i class="fa fa-download"></i>
                                </a>`);
})

</script>