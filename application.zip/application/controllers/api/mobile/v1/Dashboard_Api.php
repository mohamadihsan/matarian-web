<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Dashboard_Api extends REST_Controller {

    public function __construct()
    {
        parent::__construct();
        // validate token
        $this->token = AUTHORIZATION::validateToken();
        // load model
        $this->load->model('Dashboard_Model');
        
    }

    // tagihan
    public function show_all_tagihan_get()
    {
        $response = $this->Dashboard_Model->get_tagihan()->result();

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count tagihan
    public function count_tagihan_get()
    {
        $response['row_data'] = $this->Dashboard_Model->count_tagihan();
        $response['total_tagihan'] = abs($this->Dashboard_Model->total_tagihan()->result()[0]->sisa_ar);
        $response['last_update'] = $this->Dashboard_Model->last_update_tagihan()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // best_buyer
    public function best_buyer_get($year, $month, $limit)
    {
        $message = '';
        if ($year == "0000") {
            $year = null;
        } else {
            $message .= ' tahun '.$year;
        }
        if ($month == "0000") {
            $month = null;
        } else {
            $message .= ' bulan '.$month;
        }

        $response = $this->Dashboard_Model->best_buyer($year, $month, $limit)->result();

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data'.$message.' ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data'.$message.' tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // best seller
    public function best_seller_get($year, $month, $limit)
    {
        $message = '';
        if ($year == "0000") {
            $year = null;
        } else {
            $message .= ' tahun '.$year;
        }
        if ($month == "0000") {
            $month = null;
        } else {
            $message .= ' bulan '.$month;
        }

        $response = $this->Dashboard_Model->best_seller($year, $month, $limit)->result();

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data'.$message.' ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data'.$message.' tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count KTP
    public function count_ktp_get()
    {
        $response['row_data'] = $this->Dashboard_Model->count_ktp();
        $response['last_update'] = $this->Dashboard_Model->last_update_ktp()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count npwp
    public function count_npwp_get()
    {
        $response['row_data'] = $this->Dashboard_Model->count_npwp();
        $response['last_update'] = $this->Dashboard_Model->last_update_npwp()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count accdbrg
    public function count_accdbrg_get()
    {
        $response['row_data'] = $this->Dashboard_Model->count_accdbrg();
        $response['last_update'] = $this->Dashboard_Model->last_update_accdbrg()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count accdlgn
    public function count_accdlgn_get()
    {
        $response['row_data'] = $this->Dashboard_Model->count_accdlgn();
        $response['last_update'] = $this->Dashboard_Model->last_update_accdlgn()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count accarbon
    public function count_accarbon_get()
    {
        $response['row_data'] = $this->Dashboard_Model->count_accarbon();
        $response['last_update'] = $this->Dashboard_Model->last_update_accarbon()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count accardat
    public function count_accardat_get()
    {
        $response['row_data'] = $this->Dashboard_Model->count_accardat();
        $response['last_update'] = $this->Dashboard_Model->last_update_accardat()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response success not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }
}

/* End of file Dashboard_Api.php */
