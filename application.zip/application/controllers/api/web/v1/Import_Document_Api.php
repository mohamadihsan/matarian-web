<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Import_Document_Api extends REST_Controller {

    public function __construct()
    {
        parent::__construct();
        // validate token
        $this->token = AUTHORIZATION::validateToken();
        // load model
        $this->load->model('ACCDBRG_Model');
        $this->load->library('Excel'); //load librari excel
        
    }

    // provinsi
    public function show_all_get()
    {
        $response = $this->ACCDBRG_Model->get()->result();

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    // count
    public function count_get()
    {
        $response['row_data'] = $this->ACCDBRG_Model->count();
        $response['last_update'] = $this->ACCDBRG_Model->last_update()->result()[0]->created_at;

        if($response){
            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $response
            ], REST_Controller::HTTP_OK);
        }else{
            // response not found data
            $this->response([
                'status' => false,
                'message' => 'Data tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
    }

    public function show_by_id_get()
    {
        
    }
    
    public function create_post()
    {   
        $inputFileName = $_FILES['file']['tmp_name'];
        
        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch(Exception $e) {
            // die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            // response not found data
            $this->response([
                'status' => false,
                'message' => $e->getMessage(),
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }

        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();

        for ($row = 2; $row <= $highestRow; $row++){                  //  Read a row of data into an array                 
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);   

                // Sesuaikan key array dengan nama kolom di database                                                         
                $data[] = array(
                "kode_barang"=> $rowData[0][0],
                "golongan"=> $rowData[0][1],
                "nama_barang"=> $rowData[0][2],
                "pabrik"=> $rowData[0][3],
                "satuan"=> $rowData[0][4],
                "packing"=> $rowData[0][5],
                "satuan_per_pak"=> $rowData[0][6],
                "harga_satuan"=> $rowData[0][7],
                "harga_pokok"=> $rowData[0][8],
                "harga_beli"=> $rowData[0][9],
                "keterangan_barang"=> $rowData[0][10],
                "gudang_a"=> $rowData[0][11],
                "gudang_b"=> $rowData[0][12],
                "gudang_c"=> $rowData[0][13],
                "gudang_d"=> $rowData[0][14],
                "gudang_e"=> $rowData[0][15],
                "gudang_f"=> $rowData[0][16],
                "jumlah_stok"=> $rowData[0][17],
                "minimum"=> $rowData[0][18]
            );
                    
        }

        if (!empty($_FILES)) {

            $post['document'] = $this->input->post('type_document');
            $post['file'] = $_FILES['file'];

            //response success with data
            $this->response([
                'status' => true,
                'message' => 'Upload successfully...',
                'data' => $data
            ], REST_Controller::HTTP_OK);
        } else {
            // response not found data
            $this->response([
                'status' => false,
                'message' => 'File Document tidak ditemukan',
                'data' => []
            ], REST_Controller::HTTP_PARTIAL_CONTENT);
        }
        
    }

    public function update_put()
    {   
        
    }

    public function destroy_delete()
    {
        
    }
}

/* End of file Import_Document_Api.php */
